from Hangman import Hangman


juego = Hangman()
juego.load()
juego.get_number_of_words()
juego.playing()